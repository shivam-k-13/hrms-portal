/**
 * SPDX-FileCopyrightText: (c) 2026 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

package com.hrms.attendance.model.impl;

/**
 * @author Brian Wing Shun Chan
 */
public class AttendanceImpl extends AttendanceBaseImpl {
}
// LIFERAY-SERVICE-BUILDER-HASH:-1868329567